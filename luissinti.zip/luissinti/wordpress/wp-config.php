<?php
/**
 * Configuración básica de WordPress.
 *
 * Este archivo contiene las siguientes configuraciones: ajustes de MySQL, prefijo de tablas,
 * claves secretas, idioma de WordPress y ABSPATH. Para obtener más información,
 * visita la página del Codex{@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} . Los ajustes de MySQL te los proporcionará tu proveedor de alojamiento web.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** Ajustes de MySQL. Solicita estos datos a tu proveedor de alojamiento web. ** //
/** El nombre de tu base de datos de WordPress */
define( 'DB_NAME', 'luissinti' );

/** Tu nombre de usuario de MySQL */
define( 'DB_USER', 'root' );

/** Tu contraseña de MySQL */
define( 'DB_PASSWORD', '' );

/** Host de MySQL (es muy probable que no necesites cambiarlo) */
define( 'DB_HOST', 'localhost' );

/** Codificación de caracteres para la base de datos. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Cotejamiento de la base de datos. No lo modifiques si tienes dudas. */
define('DB_COLLATE', '');

/**#@+
 * Claves únicas de autentificación.
 *
 * Define cada clave secreta con una frase aleatoria distinta.
 * Puedes generarlas usando el {@link https://api.wordpress.org/secret-key/1.1/salt/ servicio de claves secretas de WordPress}
 * Puedes cambiar las claves en cualquier momento para invalidar todas las cookies existentes. Esto forzará a todos los usuarios a volver a hacer login.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY', 'Bh{e6u,iU(#7&m,Y#?@Rkdu{M_$v!GL*09QiW6?Bg<CZoP*8Ja_IwY?MQ1O:wDX+' );
define( 'SECURE_AUTH_KEY', 'dYXXxn#J#exAR_OY!QHAP]40lc0Q5VM@A-39?zeAK3ciy3f5%a;AD2oYjT:EtGQH' );
define( 'LOGGED_IN_KEY', '|QIhG7/:(@Tz4X]sjG4ZU8~VD2guw?IY,5U;Bh!`/&wb[h`t<O_0NVH@v7y>C^#h' );
define( 'NONCE_KEY', '|h90r!/F>-SaRq]JZN$P?9(be&x@6PUOQ+=ynBJA*3ArQyxUN@ILKQvd)#ZD`Oyv' );
define( 'AUTH_SALT', 'eTXl[:4dRg+h.b.-z1$rj@``k^hg,,2Q*ruNzrA35+<g0V_,#7}]=!vSD~H&IOf:' );
define( 'SECURE_AUTH_SALT', 'g03Kp YV|TT~89To^pGZtC6TS2a}$0-PH*]O3$_t`AII3/j1C,;#{vh?Ut&k1d9i' );
define( 'LOGGED_IN_SALT', '(F6El5O~fk<xJxr>@{5GJ_[f:(7}lTtt<#Xp` )w;G.}r=j,2#%2ES8xD~yziZt%' );
define( 'NONCE_SALT', ' z8 n_SuUHNuj^aM[omRn/%/TZvBq1%b88n&sBOf[g@;(<+Nn;5~<=gJ)sa25Mq8' );

/**#@-*/

/**
 * Prefijo de la base de datos de WordPress.
 *
 * Cambia el prefijo si deseas instalar multiples blogs en una sola base de datos.
 * Emplea solo números, letras y guión bajo.
 */
$table_prefix = 'wp_';


/**
 * Para desarrolladores: modo debug de WordPress.
 *
 * Cambia esto a true para activar la muestra de avisos durante el desarrollo.
 * Se recomienda encarecidamente a los desarrolladores de temas y plugins que usen WP_DEBUG
 * en sus entornos de desarrollo.
 */
define('WP_DEBUG', false);

/* ¡Eso es todo, deja de editar! Feliz blogging */

/** WordPress absolute path to the Wordpress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

